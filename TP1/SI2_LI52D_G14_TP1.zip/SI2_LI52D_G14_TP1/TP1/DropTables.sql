drop table if exists DAILYREG;
drop table if exists EXTTRIPLE;
drop table if exists PHONE;
drop table if exists EMAIL;
drop table if exists POSITION;
drop table if exists INSTRUMENT;
drop table if exists CLIENT_PORTFOLIO;
drop table if exists PORTFOLIO;
drop table if exists CLIENT;
drop table if exists DAILYMARKET;
drop table if exists MARKET;


